xrandr -s 1920x1080
#sets primary display
xrandr --output VGA-0 --primary
#sets secondary display with its position
xrandr --output VGA-1 --auto --right-of VGA-0
