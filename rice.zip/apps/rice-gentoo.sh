#!/bin/bash

check_dir_exists () {
	file=$1
	if [ -d $file ]; then
		exists=true
		printf "%s exists\n" $file
		printf "/usr/local/portage/net-analyzer/responder\n"
	else
		printf "%s doesn't exist\n" $file
		exists=false
		$2
	fi
}
set -e

if [ "$EUID" -ne 0 ]
  then printf "The script has to be run as root.\n"
  exit
fi

pwd=$(pwd)
cd ..
cd ..
userhome=$(pwd)

BIN_DIR=${BIN_DIR:-/usr/local/bin/}

check_dir_exists $HOME/.config
if $exists; then
	printf ".config already exists\n"
else
	mkdir $HOME/.config
	printf "creating rice directory for root\n"
fi
check_dir_exists .config
if $exists; then
	printf "users .config directory already exists\n"
else
	mkdir .config
	mkdir .config/htop
	printf "created .config directory for non root user\n"
fi
cp gentootestscript-master/aliasrc .config/
cp gentootestscript-master/htoprc .config/htop
cd $pwd

checkinstdir() {
if [ -d $1 ]; then
	printf "%s ok\n" $1
else
	printf "%s is missing\n" $1
	exit -1
fi
}

printf "Checking directories\n"
checkinstdir $BIN_DIR

printf "Adding Dots to root home\n"
cp dots/.rootbashrc /$HOME/.bashrc
cp dots/.vimrc $HOME
cp dots/.xinitrc $HOME
cp dots/.Xresources $HOME
chmod +x dots/.setres.sh
cp dots/.setres.sh $HOME

printf "Adding Dots to user home\n"
cp dots/.bashrc $userhome
cp dots/.vimrc $userhome
cp dots/.xinitrc $userhome
cp dots/.Xresources $userhome
chmod +x dots/.setres.sh
cp dots/.setres.sh $userhome

cp -r dwm $HOME/.config
cp -r dmenu $HOME/.config
cp -r slstatus $HOME/.config
cp -r st $HOME/.config

cd $HOME/.config/dwm
make clean install
printf "installed dwm\n"
cd $HOME/.config/dmenu
make clean install
printf "installed dmenu\n"
cd $HOME/.config/slstatus
make clean install
printf "installed slstatus\n"
cd $HOME/.config/st
make clean install
printf "installed st\n"

chmod +x $userhome/gentootestscript-master/finalize.sh
sh $userhome/gentootestscript-master/finalize.sh
printf "xorg can now be run as a non root user, and ALSA works now\n"

fc-cache -fv

printf "Install finished. Add software to .xinitrc to launch the DE with startx, or copy the provided .xinitrc file to your home directory (backup the old one!)\n"
